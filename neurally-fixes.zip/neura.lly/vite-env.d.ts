/// <reference types="vite/client" />

interface ImportMetaEnv {
  // Supabase's anon key is designed to be public (access is controlled by RLS policies),
  // unlike the Gemini key — that one now lives server-only in server/index.ts.
  readonly VITE_SUPABASE_URL?: string;
  readonly VITE_SUPABASE_ANON_KEY?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
