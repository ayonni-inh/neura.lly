/**
 * Replaces direct `new GoogleGenAI({apiKey}).models.*` calls in the browser.
 * The real Gemini key lives only on the server (server/index.ts) — this just
 * talks to our own /api/gemini/* routes and hands back the same shapes
 * geminiService.ts already expects, so its retry/fallback logic didn't need to change.
 */

class ApiError extends Error {
  status?: number;
  code?: string | number;
  constructor(message: string, status?: number, code?: string | number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
  }
}

async function parseErrorBody(res: Response) {
  try {
    const body = await res.json();
    return new ApiError(body.message || `Request failed: ${res.status}`, body.status ?? res.status, body.code);
  } catch {
    return new ApiError(`Request failed: ${res.status}`, res.status);
  }
}

async function post(path: string, payload: unknown) {
  const res = await fetch(`/api/gemini${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw await parseErrorBody(res);
  return res.json();
}

export const genaiProxy = {
  async generateContent(params: { model: string; contents: unknown; config?: unknown }) {
    return post('/generate-content', params);
  },

  // Returns a Promise<AsyncGenerator<...>>, matching the shape of the original
  // `ai.models.generateContentStream(...)` call. This matters: the fetch (where a
  // 503/429 actually surfaces) happens BEFORE the generator is returned, so wrapping
  // this call in retryWithBackoff still retries connection failures the same way it
  // did against the raw SDK. If this were a single `async function*`, the fetch
  // wouldn't run until the caller's first `.next()` — outside retryWithBackoff's try/catch.
  async generateContentStream(params: { model: string; contents: unknown; config?: unknown }) {
    const res = await fetch('/api/gemini/generate-content-stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok || !res.body) throw await parseErrorBody(res);

    async function* chunks() {
      const reader = res.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      const handleLine = (line: string) => {
        if (!line.trim()) return null;
        const parsed = JSON.parse(line);
        if (parsed.__error) throw new ApiError(parsed.message, parsed.status, parsed.code);
        return parsed;
      };

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const line of lines) {
          const chunk = handleLine(line);
          if (chunk) yield chunk;
        }
      }
      if (buffer.trim()) {
        const chunk = handleLine(buffer);
        if (chunk) yield chunk;
      }
    }

    return chunks();
  },

  async generateVideos(params: { model: string; prompt: string; config?: unknown; image?: unknown }) {
    return post('/generate-videos', params);
  },

  async getVideosOperation(params: { operation: unknown }) {
    return post('/videos-operation', params);
  },

  /** Returns an object URL for the downloaded video — caller is responsible for revoking it. */
  async downloadVideo(uri: string): Promise<string> {
    const res = await fetch(`/api/gemini/video-download?uri=${encodeURIComponent(uri)}`);
    if (!res.ok) throw await parseErrorBody(res);
    const blob = await res.blob();
    return URL.createObjectURL(blob);
  },
};

export { ApiError };
