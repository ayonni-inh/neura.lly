# neurAlly 2.0 — Cognitive Mirror AI Assistant

An AI-powered cognitive extension and strategic partner application. Works as an externalized executive function—analyzing user input, maintaining persistent context, and reflecting insights back to accelerate decision-making.

## Core Philosophy: The Cognitive Mirror

**Three Foundational Pillars:**
1. **Reduction of Cognitive Load** — Filter chaos into clarity; turn "what should I do?" into "do this"
2. **Preservation of Context** — Maintain continuous narrative; identify patterns users are too close to see
3. **Pragmatic Feedback Loop** — Reflect contradictions, force confrontation with constraints, optimize for momentum

**The Core Equation:** `Input (Your Ambiguity) + Context (Our History) + Constraints (Reality) = High-Impact Action`

## Tech Stack

- **Frontend:** React 19, TypeScript, Tailwind CSS
- **Build Tool:** Vite (port 5000)
- **Backend:** Express (`server/index.ts`, port 3001) — holds the Gemini API key server-side and proxies all model calls; the browser never sees the key
- **AI:** Google Gemini via `@google/genai` (called from the server, not the browser)
- **Storage:** IndexedDB (local-first) + optional Supabase sync (see `supabase/schema.sql`)
- **Cognitive Engine:** Proprietary reflection loop, personality adaptation, and memory management
- **Animations:** Framer Motion (motion)
- **Icons:** lucide-react

## Architecture: The Cognitive Brain Layers

```
.
├── App.tsx                     # Main orchestrator & chat interface
├── server/
│   └── index.ts                # Express proxy: holds GEMINI_API_KEY, forwards model calls
├── services/
│   ├── cognitiveEngine.ts      # BRAIN: Reflection loops, belief tracking, personality drift
│   ├── geminiService.ts        # AI interface (text, image, video generation) — business logic only
│   ├── apiClient.ts            # Thin HTTP client that talks to server/index.ts (no key here)
│   └── db.ts                   # Persistence: IndexedDB + Supabase sync
├── supabase/
│   └── schema.sql              # Tables + RLS matching what db.ts reads/writes
├── types.ts                    # Data structures (UserBelief, ConversationTheme, CognitiveState, etc.)
├── constants.ts                # System instructions (enforces Cognitive Mirror behavior)
├── components/                 # UI layer (reflection surface)
└── utils/                      # Helpers (markdown, supabase)
```

## Cognitive Features

### 1. Memory & Context Layers
- **User Beliefs** — Extracts and tracks core beliefs mentioned in conversation
- **Conversation Themes** — Detects recurring topics (Career, Financial, Health, Creativity, Decision Making, etc.)
- **Growth Metrics** — Tracks personal development and progress over time
- **Persistent State** — All cognitive data saved to IndexedDB, survives sessions

### 2. Reflection Engine
- **Cognitive Analysis** — Before responding, analyzes user beliefs and themes
- **Pattern Detection** — Identifies cycles, contradictions, and blind spots
- **Context Injection** — Prepends user profile and cognitive history to every prompt
- **Structured Footer** — Every response ends with **Insight**, **Opportunity**, **Action** (IOA)

### 3. Personality Adaptation
- **Communication Style Detection** — Direct, collaborative, exploratory, or technical
- **Emotional Pattern Recognition** — Calm, energetic, anxious, or focused states
- **Decision Style Tracking** — Analytical, intuitive, pragmatic, or balanced approaches
- **Real-Time Adaptation** — AI adjusts tone and depth based on detected patterns

## Running the App

```bash
npm install
cp .env.example .env   # then fill in GEMINI_API_KEY at minimum
npm run dev
```

`npm run dev` runs the Vite client (port 5000) and the Express proxy (port 3001)
together via `concurrently`; Vite proxies `/api/*` requests to the Express server
(see `vite.config.ts`). App runs at http://localhost:5000.

Only need one half at a time? `npm run dev:client` / `npm run dev:server`.

## Environment Variables

See `.env.example` for the full list with comments. Summary:

Server-only (read by `server/index.ts` via `process.env`, never bundled to the client):
- `GEMINI_API_KEY` — required. Server refuses to start without it.
- `PORT` — optional, defaults to 3001.

Client-safe (read by the browser via `import.meta.env`, safe to expose since access is
controlled by Supabase RLS policies, not by secrecy):
- `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY` — optional. Leave both unset to run
  local-only (IndexedDB, no cloud sync). Run `supabase/schema.sql` in the Supabase SQL
  editor once before setting these.

## Key Functions

### CognitiveEngine (services/cognitiveEngine.ts)
- `updateState(messages, userProfile)` — Update engine with new conversation data
- `generateIOA(userMessage, profile)` — Generate Insight/Opportunity/Action footer
- `buildContextInjection(profile)` — Create context window for prompt injection
- `extractBeliefs(message)` — Mine user beliefs from natural language
- `detectThemes(messages)` — Identify conversation themes and intensity
- `adaptPersonality(userMessage, response)` — Learn communication patterns

### Database (services/db.ts)
- `getCognitiveState()` / `saveCognitiveState(state)` — Persist cognitive memory
- `getProfile()` / `saveProfile(profile)` — User profile management

## Deployment

No longer a pure static site — `server/index.ts` needs to run as a Node process
(it holds `GEMINI_API_KEY` and serves the built client). Any Node host works
(Replit, Render, Railway, Fly.io, a VPS, etc.):

```bash
npm run build   # builds the client into dist/
npm start       # runs server/index.ts, which serves dist/ AND the /api/* routes
```

Set `GEMINI_API_KEY` (and optionally the `VITE_SUPABASE_*` vars, set at build time)
in the host's environment/secrets — never commit `.env`.

## How It Works: The Thought Flow

1. **User sends message** → Cognitive engine analyzes against stored beliefs/themes
2. **Context injection** → User history, goals, and detected patterns prepended to prompt
3. **AI processes** → Gemini responds with full context (not reset between messages)
4. **IOA footer added** → Response includes actionable Insight, Opportunity, and Action
5. **State updated** → New beliefs extracted, themes updated, personality refined
6. **Saved to storage** → Cognitive state persists for next session

This ensures the AI never resets, continuously learns your patterns, and optimizes for your momentum.
