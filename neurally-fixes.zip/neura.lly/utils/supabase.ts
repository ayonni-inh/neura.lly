import { createClient, SupabaseClient } from '@supabase/supabase-js';

// The anon key is *meant* to be public — unlike the Gemini key, access control
// here comes from Row Level Security policies (see supabase/schema.sql), not
// from keeping the key secret. That's why this is read via Vite's normal
// import.meta.env (VITE_-prefixed) instead of going through the server.
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Falls back to null when unconfigured, exactly like the old stub — every
// call site in services/db.ts already checks for that and falls back to
// local IndexedDB, so cloud sync is opt-in: unset the env vars and neurAlly
// runs local-only with zero code changes.
export const supabase: SupabaseClient | null =
  supabaseUrl && supabaseAnonKey ? createClient(supabaseUrl, supabaseAnonKey) : null;
