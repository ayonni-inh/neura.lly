-- neurAlly 2.0 — Supabase schema
--
-- Run this once in the Supabase SQL editor (Project → SQL Editor → New query)
-- for a fresh project. It creates exactly the tables/columns services/db.ts
-- already reads and writes, so no application code changes are needed beyond
-- setting VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.
--
-- IMPORTANT — single-user model:
-- neurAlly has no real authentication (the "login" screen is a local alias,
-- not Supabase Auth), so these RLS policies are scoped to the `anon` role,
-- not to a signed-in user. That means anyone holding your anon key can read
-- and write this data — fine for a personal project where the anon key isn't
-- shared, but NOT a substitute for real per-user isolation. If you ever add
-- Supabase Auth, add a `user_id uuid references auth.users` column to each
-- table and rewrite these policies to check `auth.uid() = user_id` instead.

create table if not exists sessions (
  id text primary key,
  title text not null default '',
  messages jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists images (
  id text primary key,
  url text not null,
  prompt text not null default '',
  timestamp timestamptz not null default now()
);

create table if not exists logs (
  id bigint generated always as identity primary key,
  timestamp timestamptz not null default now(),
  level text not null check (level in ('info', 'warn', 'error')),
  message text not null,
  details jsonb
);
create index if not exists logs_by_timestamp on logs (timestamp);

create table if not exists tasks (
  id text primary key,
  text text not null,
  completed boolean not null default false,
  priority text not null default 'medium' check (priority in ('low', 'medium', 'high')),
  created_at timestamptz not null default now()
);

-- Single row: db.ts always reads this with `.single()` and always upserts the
-- same fixed id ('default'), so this intentionally never grows past one row.
create table if not exists profiles (
  id text primary key default 'default',
  name text,
  role text,
  goals jsonb not null default '[]'::jsonb,
  constraints jsonb not null default '[]'::jsonb,
  preferences jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists activities (
  id bigint generated always as identity primary key,
  action text not null,
  metadata jsonb,
  timestamp timestamptz not null default now()
);

-- Row Level Security -------------------------------------------------------
alter table sessions enable row level security;
alter table images enable row level security;
alter table logs enable row level security;
alter table tasks enable row level security;
alter table profiles enable row level security;
alter table activities enable row level security;

do $$
declare
  t text;
begin
  foreach t in array array['sessions', 'images', 'logs', 'tasks', 'profiles', 'activities']
  loop
    execute format(
      'create policy if not exists "anon full access" on %I for all to anon using (true) with check (true);',
      t
    );
  end loop;
end $$;
