import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const PORT = Number(process.env.PORT) || 3001;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

if (!GEMINI_API_KEY) {
  // Fail loudly and immediately rather than letting every request 500 one at a time.
  console.error(
    '\n[neurAlly server] Missing GEMINI_API_KEY.\n' +
    'Set it in a .env file at the project root (see .env.example). This key is server-only ' +
    'and must NOT be prefixed with VITE_ — that would bundle it into the client build.\n'
  );
  process.exit(1);
}

// Single server-held client. The browser never sees this key.
const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });

const app = express();
app.use(express.json({ limit: '25mb' })); // generous limit: base64 image/video attachments ride in the body

// ---- helpers -------------------------------------------------------------

/** Normalize whatever the SDK throws into a JSON-serializable shape that preserves
 * the fields geminiService.ts already inspects (status/code/message) so its existing
 * retry + fallback-model logic keeps working unchanged. */
function serializeError(err: any) {
  const status = err?.status ?? err?.code ?? err?.error?.code ?? 500;
  const message = err?.message ?? err?.error?.message ?? 'Unknown server error';
  return {
    message,
    status: typeof status === 'number' ? status : 500,
    code: err?.code ?? err?.error?.code,
  };
}

function sendError(res: Response, err: any) {
  const body = serializeError(err);
  const httpStatus = typeof body.status === 'number' && body.status >= 400 && body.status < 600 ? body.status : 500;
  console.error('[neurAlly server] Gemini call failed:', body.message);
  res.status(httpStatus).json(body);
}

/** GenerateContentResponse exposes .text/.data/.functionCalls as computed getters on the
 * class prototype, not own data properties — so a plain JSON.stringify (what res.json does)
 * silently drops them. Flatten them into real fields while we still have the live instance. */
function flattenGenerateContentResponse(response: any) {
  const plain = JSON.parse(JSON.stringify(response));
  plain.text = response.text;
  plain.data = response.data;
  plain.functionCalls = response.functionCalls;
  plain.executableCode = response.executableCode;
  plain.codeExecutionResult = response.codeExecutionResult;
  return plain;
}

// ---- routes ---------------------------------------------------------------

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, hasKey: Boolean(GEMINI_API_KEY) });
});

app.post('/api/gemini/generate-content', async (req: Request, res: Response) => {
  try {
    const { model, contents, config } = req.body;
    const response = await ai.models.generateContent({ model, contents, config });
    res.json(flattenGenerateContentResponse(response));
  } catch (err) {
    sendError(res, err);
  }
});

app.post('/api/gemini/generate-content-stream', async (req: Request, res: Response) => {
  const { model, contents, config } = req.body;
  let startedStreaming = false;

  try {
    const stream = await ai.models.generateContentStream({ model, contents, config });

    res.setHeader('Content-Type', 'application/x-ndjson');
    res.setHeader('Cache-Control', 'no-cache');

    for await (const chunk of stream) {
      startedStreaming = true;
      res.write(JSON.stringify(flattenGenerateContentResponse(chunk)) + '\n');
    }
    res.end();
  } catch (err) {
    if (!startedStreaming) {
      // Nothing sent yet — respond with a normal error the client's retry logic can parse.
      sendError(res, err);
    } else {
      // Mid-stream failure: headers are already sent, so signal the error inline
      // and let the client-side generator throw it.
      const body = serializeError(err);
      res.write(JSON.stringify({ __error: true, ...body }) + '\n');
      res.end();
    }
  }
});

app.post('/api/gemini/generate-videos', async (req: Request, res: Response) => {
  try {
    const { model, prompt, config, image } = req.body;
    const request: any = { model, prompt, config };
    if (image) request.image = image;
    const operation = await ai.models.generateVideos(request);
    res.json(operation);
  } catch (err) {
    sendError(res, err);
  }
});

app.post('/api/gemini/videos-operation', async (req: Request, res: Response) => {
  try {
    const { operation } = req.body;
    const updated = await ai.operations.getVideosOperation({ operation });
    res.json(updated);
  } catch (err) {
    sendError(res, err);
  }
});

// Video bytes live behind Google's API key too, so proxy the download rather than
// handing the client a URI it can't authenticate.
app.get('/api/gemini/video-download', async (req: Request, res: Response) => {
  try {
    const uri = req.query.uri as string;
    if (!uri) return res.status(400).json({ message: 'Missing uri query param' });

    const upstream = await fetch(uri, { headers: { 'x-goog-api-key': GEMINI_API_KEY! } });
    if (!upstream.ok || !upstream.body) {
      return res.status(upstream.status).json({ message: 'Failed to fetch generated video' });
    }

    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'video/mp4');
    const reader = upstream.body.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      res.write(value);
    }
    res.end();
  } catch (err) {
    sendError(res, err);
  }
});

// ---- static client (production) -------------------------------------------

const distPath = path.join(__dirname, '..', 'dist');
app.use(express.static(distPath));
app.use((req: Request, res: Response, next: NextFunction) => {
  if (req.method !== 'GET' || req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(distPath, 'index.html'), (err) => {
    if (err) next();
  });
});

app.listen(PORT, () => {
  console.log(`[neurAlly server] listening on http://localhost:${PORT}`);
});
